1. Name (Project heading) : 1045_SPEAK INDIA - A VOICE TRANSLATOR

2. Remote Centre ID (RC_ID) : 1045

3. College / Institute Name : Saveetha Engineering College

4. City, State, Pin Code : Thandalam,Tamil Nadu,Chennai 602105,

5. Name/�s of the Student : Mrs.V.Ajitha, M.E.,(Ph.D.)

Team Members: VARUN S ,   VIGNESH N , WASIL MASOOD P R   
6. About (Short Description / Summary):

	�SPEAK INDIA - A VOICE TRANSLATOR� is an Android application that can be installed in any Android devices to translate voice from one language to another. In this the user gives the voice input in his own language and gets the translated output in the form of both text and voice. Thus it helps the user to get familiarized with the languages that he does not know. This also helps the user to know the proper pronunciation of the words in the language that he doesn�t know. This project also helps in conversation between two users who are from different natives. This also helps students who are curious in learning new languages. This also helps business men who have their establishments all over the world. There is an added advantage where the translated words will be stored in History and these words can be reviewed for later use. Hence the user can get more knowledge about the words that are being used for translation. The user can also obtain the output in Indian languages which is a new feature. There are not many languages that will give the output in Indian languages in the form of voice. But this application enhances this criteria. The use of Google app-engine has made this phenomenon possible. However, for foreign languages we use �Bing� translator which is a freeware.
7. Install (Installation procedure): 

1. SOFTWARE      : This folder consists softwares which are used in the proposed system.
			ADK BUNDLE with ECLIPSE AND SDK MANAGER.


2. CODING        : This folder comprises the entire programming code implemented in the project.

3. DOCUMENTATION : This folder consists of Software Requirement Specification document of the project.

4. DEMO          : This folder consists of APK file(.apk) which is the installation file used in android devices for installing the software.

5. PPT           : This folder contains the Paper Presentation that is used during the project review for the clear understanding of the concepts and methods 	          		   implemented.

